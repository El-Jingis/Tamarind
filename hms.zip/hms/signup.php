<?php
require_once("includes/db.con.php");
if(isset($_POST['signup'])){
$username = mysqli_real_escape_string($link,$_POST['username']);
$email = mysqli_real_escape_string($link,$_POST['email']);
$pass1 = mysqli_real_escape_string($link,$_POST['pass1']);
$pass2 = mysqli_real_escape_string($link,$_POST['pass2']);
$error =array();
//checking to if the form was submitted empty
if(empty($username) && empty($email) && empty($pass1) && empty($pass2)){
$error[] = "All field are required";
}
elseif(empty($username)){
$error[] = "user name field is required";
}
elseif(empty($email)){
$error[] = "email field is required";
}
elseif(empty($pass1)){
$error[] = "password field is required";
}
elseif($pass1 != $pass2){
$error[] = "password does not match";
}
else{
$insert = "INSERT INTO(user_name,email,password)VALUES('$username','$email','$password')";
$query = @mysqli_query($link,$insert);
if($query){
header("location:thanks.php");
}
else{
$error_message ='<span class="error">' ;
foreach($error as $key => $values) {
$error_message.= "$values";
}
$error_message.= "</span> <br/><br/>";
}
}
}
?>