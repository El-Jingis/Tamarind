<?php
require_once("includes/signup.php");
session_start();
require_once 'config.php';
$user_obj = new Hostel();
$data = $user_obj->logout();