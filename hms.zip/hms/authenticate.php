<?php
require_once("includes/conx.php");
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];
}
if(isset($_POST['submit'])){
$reg = mysqli_real_escape_string($link,$_POST['reg']);
$name = mysqli_real_escape_string($link,$_POST['name']);
$gender = mysqli_real_escape_string($link,$_POST['gender']);
$number = mysqli_real_escape_string($link,$_POST['s_number']);
$b_group = mysqli_real_escape_string($link,$_POST['b_group']);
$f_address = mysqli_real_escape_string($link,$_POST['f_address']);
$s_address = mysqli_real_escape_string($link,$_POST['s_address']);
if(empty($reg) ||empty($name) ||empty($gender) ||empty($number) ||empty($b_group) ||empty($f_address) ||empty($s_address)){
echo ' sorry all filed are required';
exit;
}
else if(empty($reg)){
echo 'registration number is required';
exit;
}
else if(empty($name)){
echo 'Name field is required';
exit;
}
else if(empty($number)){
echo 'phone number is required';
exit;
}
else if(empty($b_group)){
echo 'blood group is required';
exit;
}
else if(empty($f_address)){
echo 'first address is required';
exit;
}
else if(empty($s_address)){
echo 'second address is required';
exit;
}
$query = "UPDATE users SET name = '$name', 
				reg_num = '$reg', gender = '$gender',
				phone_num = '$number' , blood_group = '$b_group',
				first_address = '$f_address',
				second_address = '$s_address'WHERE u_id = '$uid' LIMIT 1";
$result = mysqli_query($link,$query);
if($result){
header("location:home.php?bello=student.next");
}
else{
echo'Sorry fail to insert';
}
}
?>