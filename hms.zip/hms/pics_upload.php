<?php
require_once("includes/conx.php");
if(isset($_POST['file'])){
$bid = preg_replace("#[^0-9]#", '' , $_POST['file']);
			// escape variables for security
			$photo = $_FILES["file"]["name"]; // The file name
			$photo_tmp = $_FILES["file"]["tmp_name"]; // File in the PHP tmp folder
			$photo = preg_replace('#[^a-z.0-9]#i', '', $photo); 
			$kaboom = explode(".", $photo); // Split file name into an array using the dot
			$fileExt = end($kaboom); // Now target the last array element to get the file extension
			// START PHP Image Upload Error Handling --------------------------------------------------
			$b_image = time().rand().".".$fileExt;
			move_uploaded_file($photo_tmp, "uploads/$photo");
			$sql = mysqli_query($link,"UPDATE users SET photo = '$photo' WHERE u_id = 'uid'");
			}

?>