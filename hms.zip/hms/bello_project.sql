-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2015 at 06:28 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bello_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `username` varchar(40) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `username`, `name`, `password`) VALUES
(1, 'maryambaraya@gmail.com', 'Baraya''s', 'Maryam Baraya', '637929a0f8657aac6357c7bc05754b02');

-- --------------------------------------------------------

--
-- Table structure for table `confirm_hostel`
--

CREATE TABLE IF NOT EXISTS `confirm_hostel` (
`id` int(11) NOT NULL,
  `hostel_name` varchar(200) NOT NULL,
  `num_room` int(11) NOT NULL,
  `reg_num` varchar(200) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `confirm_hostel`
--

INSERT INTO `confirm_hostel` (`id`, `hostel_name`, `num_room`, `reg_num`) VALUES
(1, 'Mohammed Buhari House', 1, '11/341067'),
(2, 'Mohammed Buhari House', 1, '12u/341002'),
(3, 'Mohammed Buhari House', 1, '11/341004');

-- --------------------------------------------------------

--
-- Table structure for table `hostels`
--

CREATE TABLE IF NOT EXISTS `hostels` (
`h_id` int(11) NOT NULL,
  `hostel_name` varchar(200) NOT NULL,
  `available` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `block_image` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `hostels`
--

INSERT INTO `hostels` (`h_id`, `hostel_name`, `available`, `description`, `price`, `block_image`) VALUES
(1, 'Mohammed Buhari House', 96, 'this block is mainly for male student in the federal college of education gombe. The hostel is accommodating 120 student where  each room is containing 2 beds . The hostel have 60 rooms  that''s why the hostel fee is 30 dollar.', '30', '14443494592698.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reserve_hostel`
--

CREATE TABLE IF NOT EXISTS `reserve_hostel` (
`id` int(11) NOT NULL,
  `hostel_name` varchar(200) NOT NULL,
  `num_room` varchar(200) NOT NULL,
  `restime` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `reserve_hostel`
--

INSERT INTO `reserve_hostel` (`id`, `hostel_name`, `num_room`, `restime`) VALUES
(1, 'Mohammed Buhari House', '1', '2015-10-08 21:39:38'),
(2, 'Mohammed Buhari House', '1', '2015-10-08 21:43:29'),
(3, 'Mohammed Buhari House', '1', '2015-10-08 21:45:56'),
(4, 'Mohammed Buhari House', '1', '2015-10-08 21:50:49'),
(5, 'Mohammed Buhari House', '1', '2015-10-08 21:52:50'),
(6, 'Mohammed Buhari House', '1', '2015-10-08 22:02:28'),
(7, 'Mohammed Buhari House', '1', '2015-10-08 22:08:01'),
(8, 'Mohammed Buhari House', '1', '2015-10-08 22:12:34'),
(9, 'Mohammed Buhari House', '1', '2015-10-09 08:42:55'),
(10, 'Mohammed Buhari House', '1', '2015-10-09 08:47:10'),
(11, 'Mohammed Buhari House', '1', '2015-10-09 08:57:52'),
(12, 'Mohammed Buhari House', '1', '2015-10-09 08:59:13'),
(13, 'Mohammed Buhari House', '1', '2015-10-09 08:59:54'),
(14, 'Mohammed Buhari House', '1', '2015-10-09 09:04:48'),
(15, 'Mohammed Buhari House', '1', '2015-10-09 09:08:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`u_id` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0',
  `photo` varchar(200) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(250) NOT NULL,
  `reg_num` varchar(50) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `phone_num` varchar(200) DEFAULT NULL,
  `blood_group` varchar(200) DEFAULT NULL,
  `first_address` text,
  `second_address` text,
  `fathers_name` varchar(200) DEFAULT NULL,
  `mothers_name` varchar(200) DEFAULT NULL,
  `parant_phone_num` varchar(200) DEFAULT NULL,
  `fathers_address` text,
  `mothers_address` text
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `active`, `photo`, `user_name`, `email`, `password`, `reg_num`, `name`, `gender`, `phone_num`, `blood_group`, `first_address`, `second_address`, `fathers_name`, `mothers_name`, `parant_phone_num`, `fathers_address`, `mothers_address`) VALUES
(1, '1', '144435155820631.jpg', 'Maryam', 'maryambaraya@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', '11/341067', 'Maryam Baraya', 'Male', '08130896007', 'o+', 'yola', 'yola', 'Babagari Baraya', 'Amina Baraya', '0000000000000', 'yola', 'yola'),
(2, '1', '', 'El-Jingis', 'eljingis@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', '12u/341002', 'El-jingis El-mohammed', 'Male', '07068000876', 'o+', 'mubi', 'yola', 'El-Jingis', 'Hajjiya Zainab', '00000000000', 'yola', 'mubi'),
(3, '1', '', 'Ben', 'ben@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', '11/341004', 'Benjamin Birma', 'Male', '00000000033', 'a+', 'gombe', 'gombe', 'Birma', 'Dije', '23455676543', 'gombe', 'gombe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `email` (`email`,`username`);

--
-- Indexes for table `confirm_hostel`
--
ALTER TABLE `confirm_hostel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostels`
--
ALTER TABLE `hostels`
 ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `reserve_hostel`
--
ALTER TABLE `reserve_hostel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`u_id`), ADD UNIQUE KEY `user_name` (`user_name`), ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `confirm_hostel`
--
ALTER TABLE `confirm_hostel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `hostels`
--
ALTER TABLE `hostels`
MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reserve_hostel`
--
ALTER TABLE `reserve_hostel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
