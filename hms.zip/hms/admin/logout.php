<?php
require_once("includes/hostel_query.php");
session_start();
require_once 'config.php';
$user_obj = new Hostel_query();
$data = $user_obj->logout();