//ajax processing
function showusers(tbl){
var a = tbl.split("_");
document.getElementById("returnData").innerHTML = "Double checking availability...";
var hr = new XMLHttpRequest();
var users = "ajax_php.php";
hr.open("POST", users, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.onreadystatechange = function(){
if(hr.readyState == 4 && hr.status == 200){
var return_data = hr.responseText.split(" | ");
document.getElementById("returnData").innerHTML = return_data;
window.location = "home.php?bello=users";
}
}
hr.send("get_users="+a[1]+"&num="+a[2]);
}