<?php
$link = @mysqli_connect("localhost","root","");
    $select = @mysqli_select_db($link,"bello_project");


?>