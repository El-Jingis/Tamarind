<?php  
require("includes/conx.php");
?>
<?php
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];
$sql = "select * from admin WHERE id = '$uid' LIMIT 1";
$result = mysqli_query($link, $sql);
while($row = mysqli_fetch_assoc($result)){
 $email = $row['email'];
 $name = $row['name'];
 $user_name = $row['username'];
 $password = $row['password'];
 }
 }
?>
<div class="clo-lg-6 clo-md-6 col-sm-6 bord">
<div class="top menu">Edit Profile</div>
<div class="holder">
<?php
 if(isset($_POST['submit'])){
 //initiating the variables
 $username = mysqli_real_escape_string($link,$_POST['username']);
  $name = mysqli_real_escape_string($link,$_POST['name']);
   $email = mysqli_real_escape_string($link,$_POST['email']);
    $password = mysqli_real_escape_string($link,$_POST['password']);
		$encrypt = md5($password);
	//checking all field to see if the are empty
	if(empty($username) || empty($name) || empty($email) || empty($password)){
	echo "<span class='error'>All field are required</span>";
	}
	//checking username field to see if the are empty
	else if(empty($username)){
	echo "<span class='error'>user name field is required</span>";
	}
	//checking name field to see if the are empty
	else if(empty($name)){
	echo "<span class='error'>name field is required</span>";
	}
	//checking email field to see if the are empty
	else if(empty($email)){
	echo "<span class='error'>email field is required</span>";
	}
	//checking password field to see if the are empty
	elseif(empty($password)){
	echo "<span class='error'>password field is required</span>";
	}
	//query for updating the previous record of the user
	else{
	$sql = mysqli_query($link,"UPDATE admin SET username = '$username',name = '$name', email = '$email',
						password = '$encrypt' WHERE id = '$uid'");
	if($sql){
	echo "<h4 style='color:green;'>Your record is successfully updated</h4>";
	}
	else{
	echo "<span class='error'>fail to update your record try again</span>";
	}
	}
 }
 
?>
<form action="" method="post">
<div class="form-group"><b>User Name</b>
<input type="text" name="username" class="form-control" value="<?php echo $user_name;?>" />
</div>
<div class="form-group"><b>Name</b>
<input type="text" name="name" class="form-control" value="<?php echo $name;?>" />
</div>
<div class="form-group"><b>Email</b>
<input type="email" name="email" class="form-control" value="<?php echo $email;?>" />
</div>
<div class="form-group"><b>Password</b>
<input type="password" name="password" class="form-control" value="<?php echo $password;?>" />
</div>
<div class="form-group">
<button class="btn btn-block btn-primary" type="submit" name="submit">Edit Profile</button>
</div>
</form>
</div>
</div>
</div><!--col-8-->