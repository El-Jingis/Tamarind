<?php
require_once("includes/hostel_query.php");
//gap the category from the database and display category on the select category option.
	$bello = new Hostel_query();
		$block = $bello->getblock();
//gap the category from the database and display category on the select category option.
	//$naira_market = new Naira_market();
		//$add_product = $naira_market->New_product();		
?>
<div class="clo-lg-6 clo-md-6 col-sm-6 borders margin">
<?php
require_once("includes/hostel_insert.php");
	if(!empty($_POST)){
			$hostel = new Hostel_insert();
			$data = $hostel->rooms( $_POST );
	}
?>
<div class="top menu"><b>Add Rooms</b></div>
<div class="holder">
<form action="" method="post">
<div class="form-group">
<b>Block</b>
<select name="b_name" class="form-control">
<option>Select block</option>
<?php  foreach ($block as $key=>$blocks){ ?>
<option value="<?php echo $key; ?>"><?php echo $blocks; ?></option>
<?php } ?>
</select>
</div><!--form-grouper-->
<div class="form-group"><b>Room Name</b><input type="text" name="r_name" class="form-control" placeholder="Room Name" /></div><!--form-grouper-->
<div class="form-group">
<b>Number of Bed</b>
<select name="n_bed" class="form-control">
<option>Select numbers of bed</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
</select>
</div><!--form-grouper-->
<div class="form-group"><b>Room Description</b><textarea name="r_description" rows="10" class="form-control" placeholder="Room Description"></textarea></div><!--form-grouper-->
<button class="btn btn-block btn-login" type="submit">Add Room</button>
</form>
</div>
</div><!--class cols-->
<div class="clo-lg-3 clo-md-3 col-sm-3">
</div><!--class cols-->