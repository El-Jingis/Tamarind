<div class="col-lg-9 col-md-9 col-sm-9 bord">
</div><!--col-->