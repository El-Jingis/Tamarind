<?php
if(isset($_SESSION['email']))
{
$_SESSION['u_id'];
}
else{
header("location:index.php");
}?>
<div class="clo-lg-6 clo-md-6 col-sm-6 bord">
<div class="top menu">Add a Block</div>
<div class="holder">
<?php
require_once("includes/hostel_insert.php");
	if(!empty($_POST)){
			$hostel = new Hostel_insert();
			$data = $hostel->blocks( $_POST );
	}
?>
<form action="" method="post" enctype="multipart/form-data">
<div class="form-group"><b>Block Name</b><input type="text" name="b_name" class="form-control" placeholder="Block Name" />
</div><!--form-grouper-->
<div class="form-group"><b>Numbers of Bed</b>
<input type="text" name="n_room" class="form-control" placeholder="numbers of Beds in the hostel" />
</div><!--form-grouper-->
<div class="form-group"><b>Price</b>
<input type="text" name="price" class="form-control" placeholder="Price of the hostel" />
</div><!--form-grouper-->
<div class="form-group"><b>Block image</b><input type="file" name="b_image" class="form-control" /></div><!--form-grouper-->
<div class="form-group"><b>Block Description</b><textarea name="b_description" rows="10" class="form-control" placeholder="Block Description"></textarea></div><!--form-grouper-->
<button class="btn btn-block btn-primary" type="submit">Add Hostel</button>
</form>
</div>
</div><!--class cols-->
<div class="clo-lg-3 clo-md-3 col-sm-3">
</div><!--class cols-->
