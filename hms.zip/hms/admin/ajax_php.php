<div class="top menu">View student who booked bed and have accommodation</div>
<div class="holder">
<?php
require("includes/conx.php");
if(isset($_POST['get_users']))
{
	$bid = preg_replace("#[^0-9]#", '' , $_POST['num']);
 $query = mysqli_query($link,"SELECT * FROM users 
INNER JOIN confirm_hostel ON users.reg_num = confirm_hostel.reg_num WHERE users.active = '1' LIMIT 10");
	while($check_num = mysqli_fetch_array($query)){
	 $reg = $check_num['reg_num'];
	 $photo = $check_num['photo'];
	 $name = $check_num['name'];
	 $hostel = $check_num['hostel_name'];
	 $gender = $check_num['gender'];
	 $phone = $check_num['phone_num'];
echo "<div class=\"container bord\">
<div class=\"row bords\" style=\"margin:2px;\">
<div class=\"col-lg-5 col-md-5 col-sm-5\" style=\"padding-top:8px;\">

<div class=\"thumbnail pic\">";

 if($photo != ""){
echo "<img src=\"../uploads/$photo\" width='100%' height=\"pic\" />";
}
else{
 echo "<img src=\"../images/user.png\" width=\"100%\" height=\"200\" />";
}
echo "</div>
</div>
<div class=\"col-lg-7 col-md-7 col-sm-7\"><b>NAME:</b>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$name<br>
<b>REG NUMBER:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $reg<br>
 <b>PHONE NUMBER:</b>&nbsp;&nbsp;&nbsp; $phone<br>
 <b>GENDER:</b>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$gender<br>
 <b>HOSTE NAME:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $hostel
</div>
</div>
</div>";
}
 }
?>
</div>
</div>