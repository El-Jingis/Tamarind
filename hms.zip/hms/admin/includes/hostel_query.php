 <?php
 require_once("db.con.php");
class Hostel_query{
public function __construct()
{
$db = new  Database();
$this->_con = $db->con;
}
	
//login into your profile function
public function login(){
if(isset($_POST['submit'])){
		
//email id		
if(empty($_POST['email'])){
echo'<span class="error">please enter a email.</span> <br />';
}	
else {
$email = mysqli_real_escape_string($this->_con, strip_tags($_POST['email']));
} 		
//password
if(empty($_POST['password'])){
echo'<span class="error">please enter a password.</span>';
}	
else {
$upassword = md5($_POST['password']);
$password = mysqli_real_escape_string($this->_con, $upassword);
}	
		
if (!empty($email)&& !empty($password)){
                    
$sql = "SELECT * FROM admin WHERE email='$email' AND password='$password' LIMIT 1";
$result = mysqli_query($this->_con,$sql);
             
if(mysqli_num_rows($result)==1){
$row = mysqli_fetch_array($result);
    $login_email = $row['email'];
          $user_id = $row['id'];
if(isset($login_email)&&  $user_id ){
    $_SESSION['u_id'] =  $row['id']; 
    $_SESSION['email'] =  $row['email'];
	$_SESSION['name'] = $row['name'];
    header('location:home.php');
    exit();
    }  	                                				
}else{
echo'<span class="error"> email ID or password is incorrect</span> <br /> <br />' ;
}
}
}
}
/**
* This handle sign out process
*/
public function logout()
{
session_unset();
session_destroy();
session_start();
$_SESSION['success'] = LOGOUT_SUCCESS;
header('Location: index.php');
}
public function getblock(){
$query = "SELECT * FROM hostels";
$results = mysqli_query($this->_con, $query)  or die(mysqli_error());
$block = array();
while ( $result = mysqli_fetch_assoc($results) ) {
$block[$result['hostel_name']]= $result['hostel_name'];
}
mysqli_close($this->_con);
return $block;
}
//for fetching data from database and display them
public function getblocks(){
$query = "SELECT * FROM hostels";
$results = mysqli_query($this->_con, $query)  or die(mysqli_error());
mysqli_close($this->_con);
return $results;
}
}
?>