<?php
$host = "localhost";
$username = "root";
$password = "";
$db_name = "bello_project";
$link = @mysqli_connect($host , $username , $password);
    $select = @mysqli_select_db($link,"hms");


?>