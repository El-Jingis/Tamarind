<?php
//connection for our database
/*$link = @mysqli_connect("localhost","root","")or die("oops there is a problem with our server");
if($link){
@mysqli_select_db($link,"hms")or die("oops problem from our database");
}*/
define('BASE_PATH','http://localhost/phpmyadmin/emarket/');
define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','hms');
/**function __autoload($class)
{
	$parts = explode('_', $class);
	$path = implode(DIRECTORY_SEPARATOR,$parts);
	require_once $path . '.php';
}**/
class Database
{
	/**
	 * @var $con will hold database connection
	 */
	public $con;
	
	/**
	 * This will create Database connection
	 */
	public function __construct()
	{
		$this->con = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
		if( mysqli_connect_error()) echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
}
?>