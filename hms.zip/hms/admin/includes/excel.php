<?php
header("content-type:application/vnd.ms-excel");
header("content-description: attachment filename=way_to_code_excel_sheet.xls");
exit(0);
?>