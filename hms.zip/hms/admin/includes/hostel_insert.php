<?php
 require_once("db.con.php");
class Hostel_insert{
	public function __construct()
		{
			$db = new  Database();
			$this->_con = $db->con;
		}
	public function rooms( array $data ){
		if( !empty( $data ) ){
			
			// Trim all the incoming data:
			$trimmed_data = array_map('trim', $data);
			
			// escape variables for security
			$r_name = mysqli_real_escape_string( $this->_con,  $trimmed_data['r_name'] );
			$n_bed = mysqli_real_escape_string( $this->_con,  $trimmed_data['n_bed'] );
			$b_name = mysqli_real_escape_string( $this->_con,  $trimmed_data['price'] );
			$r_description = mysqli_real_escape_string( $this->_con,  $trimmed_data['r_description'] );
			if((!$r_name)||(!$n_bed)||(!$b_name)||(!$r_description)){
			echo "sorry all field are required.";
			exit;
			}
			elseif((!$r_name)){
			echo "sorry room name field is required.";
			}
			elseif((!$b_name)){
			echo "sorry block name field is required.";
			}
			elseif((!$n_bed)){
			echo "select your number of bed.";
			}
			elseif((!$r_description)){
			echo "sorry room description field is required.";
			}
			else{
			
			$query = "INSERT INTO hostels(hostel_name,available,price,description)VALUES('$r_name','$n_bed','$b_name','$r_description')";
			if(mysqli_query($this->_con, $query)){
				mysqli_close($this->_con);
				return true;
			}
	}
  }
}

	public function blocks( array $data ){
		if( !empty( $data ) ){
			
			// Trim all the incoming data:
			$trimmed_data = array_map('trim', $data);
			// escape variables for security
			$b_image = $_FILES["b_image"]["name"]; // The file name
			$b_image_tmp = $_FILES["b_image"]["tmp_name"]; // File in the PHP tmp folder
			$b_image = preg_replace('#[^a-z.0-9]#i', '', $b_image); 
			$kaboom = explode(".", $b_image); // Split file name into an array using the dot
			$fileExt = end($kaboom); // Now target the last array element to get the file extension
			// START PHP Image Upload Error Handling --------------------------------------------------
			$b_image = time().rand().".".$fileExt;
			move_uploaded_file($b_image_tmp, "../uploads/$b_image");
			$b_name = mysqli_real_escape_string( $this->_con,  $trimmed_data['b_name'] );
			$n_room = mysqli_real_escape_string( $this->_con,  $trimmed_data['n_room'] );
			$price= mysqli_real_escape_string( $this->_con,  $trimmed_data['price'] );
			$b_description = mysqli_real_escape_string( $this->_con,  $trimmed_data['b_description'] );
			if((!$b_name)||(!$n_room)||(!$b_description)||(!$b_image)||(!$price)){
			echo "sorry all field are required.";
			}
			elseif((!$b_name)){
			echo "sorry block name field is required.";
			}
			elseif((!$b_image)){
			echo "sorry block image field is required.";
			}
			elseif((!$price)){
			echo "sorry Price field is required.";
			}
			elseif((!$n_room)){
			echo "select your number of rooms.";
			}
			elseif((!$b_description)){
			echo "sorry block description field is required.";
			}
			else{
			$query = "INSERT INTO hostels(hostel_name,available,description,price,block_image) VALUES ('$b_name','$n_room','$b_description','$price','$b_image')";
			if(mysqli_query($this->_con, $query)){
				mysqli_close($this->_con);
				return true;
			}
	}
  }
 }
}
?>