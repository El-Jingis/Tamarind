<?php  
//database connection
require("includes/conx.php");
?>
<?php
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];
$sql = "select * from admin WHERE id = '$uid' LIMIT 1";
$result = mysqli_query($link, $sql);
while($row = mysqli_fetch_assoc($result)){
 $email = $row['email'];
 $name = $row['name'];
 $user_name = $row['username'];
 }
 }
?>
<div class="col-lg-9 col-md-9 col-sm-9 bground">
<h4><?php echo"<span style='color:#4071a9;'>".$name."</span>DashBoard";?></h4>
<?php
print '<table colspan="18"  style="margin:10px;">';
print '<tr style="margin:10px;"><td></td>';
print'<td style="margin:10px;"><b>EMAIL</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'. $email.'</td></tr>';
print '<tr style="margin:10px;"><td></td>';
print'<td style="margin:10px;"><b>NAME</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'. $name.'</td></tr>';
print '</table>';
 ?>
</div><!--col-8-->