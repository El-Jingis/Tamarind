<?php 
session_start();
if(isset($_SESSION['email']))
{
$_SESSION['u_id'];
}
else{
header("location:index.php");
}
if(isset($_GET['bello'])){
	$pages = array("dashboad","blocks","rooms","view_block","users","new_user","edit_user");
	if(in_array($_GET['bello'],$pages)){
		$_page = $_GET['bello'];
	}
	else{
	$_page = "dashboad";	
	}
}
else{
	$_page = "dashboad";
}
?>
<html>
<head>
<title>Hostel Management System</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/ajax_process.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body class="bg">
<nav class=" navbar navbar-default navbar-fixed-top menu" id="my-navbar" >
<div class="navbar-header marg">Hostel Management System</div>
</div>
<button type="button" title="Menu Bar" class="navbar-toggle menu" data-toggle="collapse" data-target="#navbar-collapse">
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
</button>
<div class="collapse navbar-collapse" id="navbar-collapse">
<div class="btn-group pull-right" style="margin-top:8px; margin-right:60px;">
<button type="button" class="btn btn-default dropdown-toggle"
data-toggle="dropdown">
Account
<span class="caret"></span>
</button>
<ul class="dropdown-menu" role="menu">
<li><a href="#">my Account</a></li>
<li class="divider"></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
<ul class="nav navbar-nav pull-right">
 <li style="color:#fff;"><a href="home.php?bello=dashboad" style="color:#fff;"><?php if(isset($_SESSION['email'])){echo $_SESSION['email'];}?></a></li>
</ul>
</div>
</nav>
<div class="jumbotron bg">
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-3">
<div class="row">
<div class="col-lg-10 col-md-10 col-sm-10">
<div class="row">
<div class="form-group"><a href="home.php?bello=dashboad" class="btn btn-block btn-default">DashBoard</a></div>
</div><!--row-->
</div><!--col-11 inner-->
<div class="col-lg-10 col-md-10 col-sm-10 bground margin radius">
<div class="row radius">
<div class="bottom"><b>Hostels</b></div>
<div class="holder">
<div class="link"><a href="home.php?bello=blocks">Add Hostels</a></div>
<div class="link"><a href="home.php?bello=view_block">View Hostels</a></div>
</div>
</div><!--row-->
</div><!--col-11 inner-->
<div class="col-lg-10 col-md-10 col-sm-10 bground margin radius">
<div class="row radius">
<div class="bottom"><b>Student</b></div>
<div class="holder">
<div class="link"><a href="home.php?bello=users">View student</a></div>
</div>
</div><!--row-->
</div><!--col-11 inner-->
<div class="col-lg-10 col-md-10 col-sm-10 bground margin radius">
<div class="row radius">
<div class="bottom"><a href="home.php?bello=edit_user"><b>Admin User</b></a></div>
<div class="holder">
<div class="link"><a href="home.php?bello=new_user">New User</a></div>
</div>
</div><!--row-->
</div><!--col-11 inner-->
</div><!--row inner-->
</div><!--col-2-->
<?php require($_page.".php");?>
</div><!--row-->
</div><!--container-->
</div>
</body>