<?php 
session_start();
require_once("includes/hostel_query.php");
			if(isset($_SESSION['email'])){
				$_SESSION['u_id'];
			}
			else{
			header('Location: home.php');exit;
			}
?>

<html>
<head>
<title>Hostel Management System</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
</head>
<body class="bg">
<nav class=" navbar navbar-default navbar-fixed-top menu" id="my-navbar" >
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-3"></div>
<div class="col-lg-6 col-md-6 col-sm-6">
<div class="navbar-header marg">Hostel Management System</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3"></div>
</div>
</div>
</nav>
<div class="jumbotron bg">
<div class="container">
<div class="row">
<div class="clo-lg-4 clo-md-4 col-sm-4">
</div><!--class cols-->
<div class="clo-lg-4 clo-md-4 col-sm-4 bord">
<h2 class="text-center">Admin Sign In </h2>
<?php 
	
			$user_obj = new Hostel_query();
			$data = $user_obj->login();
 
	
?>
<form action="index.php" method="post">
<div class="form-group"><b>Email</b><input type="text" name="email" class="form-control" placeholder="email or username" /></div><!--form-grouper-->
<div class="form-group"><b>password</b><input type="password" name="password" class="form-control" placeholder="password" /></div><!--form-grouper-->
<button class="btn btn-block btn-primary" type="submit"name="submit" >Login</button>
</form>
<div class="form-footer footerf">
<div class="row">
<div class="col-lg-12 col-sm-12 col-md-12">
<a href="forget_password.php" class="btn btn-lg btn-md btn-sm btn-primary fa fa-lock"> Forgot password? </a>
<a href="#" class="btn btn-lg btn-md btn-sm btn-primary"> Public Area </a>
</div><!--div col-->
</div><!--inner rows-->
</div><!--footer-->
</div><!--class cols-->
<div class="clo-lg-4 clo-md-4 col-sm-4">
</div><!--class cols-->
</div><!--div class row main-->
</div><!--div class container main-->
</div><!--div class jumbotron main-->
</body>
</html>