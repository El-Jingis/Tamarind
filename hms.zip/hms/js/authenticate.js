//log in authentication js screen
function student(){
//creating variable for form input

var next = document.getElementById("next").value;
var name = document.getElementById("name").value;
var number = document.getElementById("number").value;
var gender = document.getElementById("gender").value;
var b_group = document.getElementById("b_group").value;
var f_address = document.getElementById("f_address").value;
var s_address = document.getElementById("s_address").value;
if(reg == "" || name =="" || number == "" || gender == "" || b_group == "" || f_address == "" || s_address ==""){
document.getElementById("returnData").innHTML = "Double checking...";
}
var confData = "next="+next+"reg="+reg+"&name="+name+"&number="+number+"&gender="+gneder+"b_group="+b_group+"f_address="+f_address+"s_address="+s_address;
var hr = new XMLHttpRequest();
var regs = "authenticate.php";
hr.open("POST", regs, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.onreadystatechange = function(){
if(hr.readyState == 4 && hr.status == 200){
var return_data = hr.responseText.split(" | ");
if(return_data[0]=="false"){
document.getElementById("returnData").innerHTML = return_data[1];
}else{
document.getElementById("returnData").innerHTML = return_data;
window.location = "home.php?bello=student.next";
}
}
}
hr.send(confData);
}