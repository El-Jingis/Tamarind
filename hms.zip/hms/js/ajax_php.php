<?php
require_once("conx.php");
/*if(isset($_POST['getbed_btns'])){
$bid = preg_replace("#[^0-9]#", '' , $_POST['getbed_btns']);
if($bid != ""){
exit;
}*/
$outputs = "";
$query = "SELECT * FROM hostels";
$results =  mysqli_query($link, $query);
$num_check = mysqli_num_rows($results);
if($num_check != 0){
while($rows = mysqli_fetch_array($results)){
$h_id = $rows['h_id'];
 $block_name = $rows['hostel_name'];
 $description = $rows['description'];
$available = $rows['available'];
$bedbtn = "" ;
$output = "";
$output .= "$block_name Now has $available Bed(s) Available.<br />";
$outputs .= "click the button to reserve a bed, will held for 10 minutes once you click.<br />";
for($k = 0; $k < $available ; $k++){
$k2 = $k+1;
$bedbtn .= '<button class="btn btn-lg btn-md btn-sm btn-default">'.$k2.'</button>' ;
}
$outputs = "$bedbtn<br />";
}
}
echo $output; 
echo $outputs;
exit;
/*}
else{
$outputs = "Sorry Bed are no longer available from that room";
}*/
//reserve bed
if(isset($_POST['reserve'])){
$gado = "";
$bid = preg_replace("#[^0-9]#", '' , $_POST['reserve']);
$num = preg_replace("#[^0-9]#", '' , $_POST['num']);
if($bid == "" || $num == ""){
exit;
}
$query = "SELECT * hostels WHERE h_id = '$bid' AND available >= '$num'";
$results = mysqli_query($link, $query);
$num_check = mysqli_num_rows($results);
if($num_check != 0){
while($rows = mysqli_fetch_assoc($results)){
$a_id = $rows['a_id'];
$room_name = $rows['room_name'];
$block_name = $rows['hostel_name'];
$description = $rows['description'];
$available = $rows['available'];
$bedbtn = "" ;
$gado .= 'You just Reserved'.$num.'bed at room' .$block_name.'<br />';
$gado .= "You only have 10 minutes to finish or your Reservation will open up to other people.<br />";
}
$avilableNow = $available - $num ;
$u_query = "UPDATE hostels SET available = '$avilableNow' WHERE a_id = '$a_id'";
$u_result = mysqli_query($link,$u_query);
//insertion into table bed reserve
$i_query = "INSERT INTO reserve_hostel(room_name,num_room restime)VALUES('$room_name','$num',NOW())";
$i_result = mysqli_query($link, $i_result);
$reserveID = mysqli_insert_id($link);
$gado .= "<form name='' action='' method=''>";
$gado .= "<input type='hidden' name='reg' id='reg' class='form-control' placeholder='Registration Number Please'  />";
$gado .= "<input type='hidden' name='room_name' id='room_name' value='$room_name' />";
$gado .= "<input type='hidden' name='num_bed' id='num_bed' value='$num' />";
$gado .= "<input type='hidden' name='reserveID' id='reserveID' value='$reserveID' />";
$gado .= "<div class='btn-group'>";
$gado .= "<button class='btn btn-lg btn-md btn-sm btn-login' id='confirm' onClick='confirmBed()'>Confirm Room</button>";
$gado .= "<button class='btn btn-lg btn-md btn-sm btn-login' id='cancel' onClick='cancelReserve(\"$reserveID\")'>Cancel Room</button>";
$gado .= "</div>";
}
else{
$godo = "Sorry someone just reserve those try another room";
$reserveID = "open";
}
echo $gado | $reserveID;
exit;
}
if(isset($_POST['clearRes'])){
$bid = preg_replace("#[^0-9]#", '' , $_POST['clearRes']);
// fetching  bed data from the database
	 $r_query = "SELECT b.*,a.available FROM hostel_reserve AS b
	 LEFT JOIN hostels AS a ON a.room_name = b.room_name WHERE b.id = '$bid'";
	 $r_results = mysqli_query($this->_con, $r_query)  or die(mysqli_error());
	 $num_check = mysqli_num_rows($r_results);
	 if($num_check != 0){
	// running the while loop for the table related at the top
	 while($rows = mysqli_fetch_assoc($r_results)){
	   $id = $rows['h_id'];
	   $room_name = $rows['room_name'];
	   $num_room = $rows['num_room'];
	   $available  = $rows['available'];
	   //add back the expire reserves
	   $updateAvailable = $available + $num_room;
	   //delete the booking from the reserve table
	   $d_query = "DELETE FROM reserve_hostel WHERE room_name ='$room_name' LIMIT 1";
	   	 $d_result = mysqli_query($this->_con, $d_query)  or die(mysqli_error());
		 	   //update the booking record
	   $u_query = "UPDATE hostels SET available = '$updateAvailable' WHERE room_name ='$room_name' LIMIT 1";
	   	 $u_result = mysqli_query($this->_con, $u_query)  or die(mysqli_error());
	 }
	 }
}
?>