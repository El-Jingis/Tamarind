var processStage = "open";
var reservationId = "open";
//start get button for block available
function showbed(tbl){
if (processStage == "closed"){
cancelReserve(reservationId);
}
var a = tbl.split("_");
document.getElementById("returnData").innerHTML = "Double checking availability...";
var hr = new XMLHttpRequest();
var page = "ajax_php.php";
hr.open("POST", page, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.onreadystatechange = function(){
if(hr.readyState == 4 && hr.status == 200){
var return_data = hr.responseText;
document.getElementById("returnData").innerHTML = return_data;
}
}
hr.send("getbed_btns="+a[1]);
}
//end of get button for block available
//begin the reserve room function
function reserveRoom(numroom){
processStage == "closed";
var a = numroom.split("_");
document.getElementById("returnData").innerHTML = "Double checking availability...";
var hr = new XMLHttpRequest();
var url = "ajax_php.php";
hr.open("POST", url, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.onreadystatechange = function(){
if(hr.readyState == 4 && hr.status == 200){
var return_data = hr.responseText.split(" | ");
reservationId = return_data[1];
document.getElementById("returnData").innerHTML = return_data[0];
}
}
hr.send("reserve="+a[1]+"&num="+a[2]);
}
//begining of confirm button
function confirmBed(){
var reg = document.getElementById("reg").value;
var room_name = document.getElementById("room_name").value;
var num_bed = document.getElementById("num_bed").value;
var reserve = document.getElementById("reserveID").value;
var confData = "confirm="+reserve+"&reg="+reg+"&room="+room_name+"&bed="+num_bed;
var hr = new XMLHttpRequest();
var pages = "ajax_php.php";
hr.open("POST", pages, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.onreadystatechange = function(){
if(hr.readyState == 4 && hr.status == 200){
var return_data = hr.responseText.split("|");
if(return_data[0] =="false"){
document.getElementById("returnData").innerHTML = return_data[1];
var processStage ="open";
var reservationId = "open";
}
else{
var processStage ="open";
var reservationId = "open";
alert("thank you for booking a bed in our hostel. Now you own the bed");
window.location = "home.php?bello=hostels";
}
}
}
hr.send("confirm="+reserve+"&reg="+reg+"&room="+room_name+"&bed="+num_bed);
}
//begining the cancelbutton
function cancelReserve(resid){
var hr = new XMLHttpRequest();
var cancel = "ajax_php.php";
hr.open("POST", cancel, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.send("clearRes="+resid);
window.location = 'home.php?bello=hostels';
}
