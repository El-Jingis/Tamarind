//jquery for picture profile uploader button
$('document').ready(function(){
	function openTerms(){
	_("pic").style.display = "block";
	emptyElement("status");
}
	 /*pics upload display sidebar page*/
	 $('#pic').click(function(){
   $('#pics').slideToggle('slow');
   });
   //begining of confirm button
function uploadPics(){
var file = document.getElementById("file").value;
if(file == ""){
return false;
}
var confData ="file="+file;
var hr = new XMLHttpRequest();
var regs = "pics_upload.php";
hr.open("POST", regs, true);
hr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
hr.onreadystatechange = function(){
if(hr.readyState == 4 && hr.status == 200){
var return_data = hr.responseText.split(" | ");
if(return_data[0]=="false"){
document.getElementById("returnData").innerHTML = return_data[1];
var processStage ="open";
var reservationId = "open";
}else{
var processStage ="open";
var reservationId = "open";
alert("Now you own the bed");
window.location = "home.php?bello=hostels";
}
}
}
hr.send(confData);
}
});