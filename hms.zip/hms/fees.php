<?php //require_once("includes/signup.php");?>
<html>
<head>
<title>Isah Abdullahi Mohammed Siwes</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar-inverse header menu" id="my-navbar" >
<div class="container">
<div class="navbar-header">
<div class="navbar-header pull-left marg"><b>Hostel Management System<b></div>
<button type="button" title="Menu Bar" class="navbar-toggle menu" data-toggle="collapse" data-target="#navbar-collapse">
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
</button>
</div><!--navbar header-->
<div class="collapse navbar-collapse" id="navbar-collapse">
<ul class="nav navbar-nav pull-right menu">
   <li><a href="#">Home</a></li>
    <li><a href="#">About</a></li>
    <li><a href="#">Book a Hostel</a></li>
    <li><a href="#">View Notice board</a></li>
    <li><a href="#">View Hostels</a></li>
</ul>
</div><!--class collapse-->
</div>
</nav>
<div class="jumbotron jumbo">
<div class="container">
<div class="row">
<div class="clo-lg-3 clo-md-3 col-sm-3">
</div><!--class cols-->
<div class="clo-lg-6 clo-md-6 col-sm-6 borders margin">
<div class="top"><b>Student Hostel Fee type Form</b></div>
<div class="holder">
<div class="form-group"><b>Fee Type</b>
<select name="" class="form-control">
<option>Select your fee type</option>
<option>Establishment fee</option>
<option>Mess advance</option>
<option>Room reservation</option>
<option>Others</option>
</select>
</div><!--form-grouper-->
<div class="form-group"><b> Cost</b>(in Naira)
<input type="text" name="username" class="form-control" placeholder="your Cost of your fee" /></div><!--form-grouper-->
<div class="form-group">
<button class="btn btn-block btn-login" type="submit" name="signup">Fee type</button>
</div>
</div><!--col-->
</div><!--holder-->
<div class="clo-lg-3 clo-md-3 col-sm-3"></div><!--class cols-->
</form>
</div><!--div class row main-->
</div><!--div class container main-->
</div><!--div class jumbotron main-->
</body>
</html>