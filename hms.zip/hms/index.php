
<?php 
session_start();
require_once("includes/signup.php");
			if(isset($_SESSION['email']) && $_SESSION['u_id']){
				$_SESSION['u_id'];
				header('Location: home.php');
			}
			else{
			//header('Location: index.php');
			}
?>
<html>
<head>
<title>Hostel Management System</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.js"></script>
    <script src="js/authenticate.js"></script>
</head>
<body class="bg">
<nav class=" navbar navbar-default navbar-fixed-top pad menu" id="my-navbar" >
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-3"></div>
<div class="col-lg-6 col-md-6 col-sm-6">
<div class="navbar-header marg">Hostel Management System</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3"></div>
</div>
</div>
<button type="button" title="Menu Bar" class="navbar-toggle menu" data-toggle="collapse" data-target="#navbar-collapse">
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
</button>
</div><!--navbar header-->
<div class="collapse navbar-collapse" id="navbar-collapse">
</div><!--class collapse-->
</div>
</nav>
<div class="jumbotron bg">
<div class="container">
<div class="row">
<div class="clo-lg-4 clo-md-4 col-sm-4 bord">
<h2 class="text-center">Sign In Here</h2>
<form id="login-form" method="post" class="form-signin" role="form" action="index.php">
<div class="form-group">
<?php
			$login = new Hostel();
			$data = $login->login();
			?>
 </div>
<div class="form-group"> 
<input name="email" id="email" type="email" class="form-control" placeholder="Email address" autofocus>
</div>
<div class="form-group"> 
<input name="password" id="password" type="password" class="form-control" placeholder="Password"> 
</div>
<button class="btn btn-block btn-primary" type="submit" name="submit">Sign in</button>
</form>
<div class="form-footer footerf divider">
<div class="row">
<div class="col--6 col-sm-6 col-md-6 link">
<i class="fa fa-lock"></i>
<a href="forget_password.php"> Forgot password? </a>
</div><!--div col-->
</div><!--inner rows-->
</div><!--footer-->
</div><!--class cols-->
<div class="clo-lg-4 clo-md-4 col-sm-4"></div><!--class cols-->
<div class="clo-lg-4 clo-md-4 col-sm-4 bord">
<h2 class="text-center">Sign Up Here</h2>
<form action="index.php" method="post">
<div class="form-group">
<?php
//require_once("includes/signup.php");
//
$hostel = new Hostel();
$hostels = $hostel->signupForm();
?>
</div><!--error display-->
<div class="form-group"><b>User Name</b><input type="text" name="username" class="form-control" placeholder="your user name" /></div><!--form-grouper-->
<div class="form-group"><b>Email</b><input type="text" name="email" class="form-control" placeholder="your email address" /></div><!--form-grouper-->
<div class="form-group"><b>Create password</b><input name="pass1" type="password" class="form-control" placeholder="create password" /></div><!--form-grouper-->
<div class="form-group"><b>Confirm Password</b><input name="pass2" type="password" class="form-control"placeholder="Confirm password"  /></div><!--form-grouper-->
<div class="form-group">
By clicking the below button you agree to our term and policy
</div><!--form-grouper-->
<button class="btn btn-block btn-primary" type="submit" name="signup">Sign UP</button>
</form>
</div><!--class cols-->
</div><!--div class row main-->
</div><!--div class container main-->
</div><!--div class jumbotron main-->
</body>
</html>