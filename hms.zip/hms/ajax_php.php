<div class=" bground bord">
<?php
require_once("includes/conx.php");
if(isset($_POST['getbed_btns'])){
$bid = preg_replace("#[^0-9]#", '' , $_POST['getbed_btns']);
$outputs = "";
$query = "SELECT * FROM hostels WHERE h_id ='$bid'";
$results =  mysqli_query($link, $query);
$num_check = mysqli_num_rows($results);
if($num_check != 0){
while($rows = mysqli_fetch_array($results)){
$h_id = $rows['h_id'];
 $block_name = $rows['hostel_name'];
 $description = $rows['description'];
$available = $rows['available'];
$bedbtn = "" ;
$output = "";
$output .= "$block_name Now has $available Bed(s) Available.<br />";
$outputs .= "click the button to reserve a bed, will held for 10 minutes once you click.<br />";
for($k = 0; $k < $available ; $k++){
$k2 = $k+1;
$bedbtn .= '<button class="btn btn-lg btn-md btn-sm btn-primary" id="bid_'.$h_id.'_'.$k2.'" onClick="reserveRoom(this.id)">Bed for sale</button>' ;
}
$outputs = "$bedbtn<br />";
}
}
echo $output; 
echo $outputs;
exit;
}
else{
$outputs = "Sorry Bed are no longer available from that room";
}
//reserve bed
if(isset($_POST['reserve'])){
$gado = "";
$gados = "";
$bid = preg_replace("#[^0-9]#", '' , $_POST['reserve']);
$num = preg_replace("#[^0-9]#", '' , $_POST['num']);
$num=1;
$query = "SELECT * FROM hostels WHERE h_id = '$bid' AND available >= '$num'";
$results = mysqli_query($link, $query);
$num_check = mysqli_num_rows($results);
if($num_check != 0){
while($rows = mysqli_fetch_assoc($results)){
$a_id = $rows['h_id'];
$block_name = $rows['hostel_name'];
$description = $rows['description'];
$available = $rows['available'];
$bedbtn = "" ;
$gado .= 'You just Reserved<b>'.$num.'bed at room' .$block_name.'</b><br />';
$gado .= "You only have 10 minutes to finish or your Reservation will open up to other people.<br />";
}
$avilableNow = $available - $num ;
$u_query = "UPDATE hostels SET available = '$avilableNow' WHERE h_id = '$a_id'";
$u_result = mysqli_query($link,$u_query);
//insertion into table bed reserve
$i_query = "INSERT INTO reserve_hostel(hostel_name,num_room,restime)VALUES('$block_name','$num',NOW())";
$i_result = mysqli_query($link, $i_query);
$reserveID = mysqli_insert_id($link);
$gado .= "<form name='form' action='' method='post' onSubmit='return false'><div class='form-group'>";
$gado .= "<input type='text' name='reg' id='reg' class='form-control' placeholder='Registration Number Please'  /></div>";
$gado .= "<input type='hidden' name='room_name' id='room_name' value='$block_name' />";
$gado .= "<input type='hidden' name='num_bed' id='num_bed' value='$num' />";
$gado .= "<input type='hidden' name='reserveID' id='reserveID' value='$reserveID' />";
$gado .= "<div class='btn-group'>";
$gado .= "<button class='btn btn-lg btn-md btn-sm btn-primary' id='confirm' onClick='confirmBed()'>Confirm your Reservation</button>";
$gado .= "<button class='btn btn-lg btn-md btn-sm btn-default' id='cancel' onClick='cancelReserve(\"$reserveID\")'>Cancel your Reservation</button>";
$gado .= "</div></form>";
}
else{
$godo = "Sorry someone just reserve those try another room";
$reserveID = "open";
}
echo $gado;
exit;
}
if(isset($_POST['confirm'])){
$bid = preg_replace("#[^0-9]#", '' , $_POST['confirm']);
$reg = preg_replace("#[^0-9a-z / ]#i", '' , $_POST['reg']);
$room = preg_replace("#[^0-9a-z]#i", '' , $_POST['room']);
$bed = preg_replace("#[^0-9]#", '' , $_POST['bed']);
$sql = mysqli_query($link, "SELECT * FROM reserve_hostel WHERE id ='$bid' LIMIT 1");
$check_num = mysqli_num_rows($sql);
if($check_num != 1){
$select = mysqli_query($link, "SELECT * FROM hostels WHERE hostel_name = '$room' AND available >= '$bed' LIMIT 1");
$check_nums = mysqli_num_rows($select);
if($check_nums == 0){
$confirms = "false";
$confirm = "Your reservation expired please try again";
echo "$confirms|$confirm";
}
else{
while($row = mysqli_fetch_array($select)){
$h_id = $row['h_id'];
$available = $row['available'] ;
$avilableNow = $available - $bed;
}
$sql = mysqli_query($link,"UPDATE hostels SET available = '$avilableNow' WHERE h_id ='$h_id' LIMIT 1");
$query = mysqli_query($link , "INSERT INTO confirm_hostel(hostel_name,num_room,reg_num)
						VALUES('$room','$bed','$reg')");
	$confirms = "true";
$confirm = "Your reservation expired please try again";
echo "$confirm|$confirms";
}
}
else{
$query = mysqli_query($link , "INSERT INTO confirm_hostel(hostel_name,num_room,reg_num)
						VALUES('$room','$bed','$reg')");
						//delete form reserve database
$query = mysqli_query($link,"DELET * FROM WHERE id = '$bid'");
//
}
}
if(isset($_POST['clearRes'])){
$bid = preg_replace("#[^0-9]#", '' , $_POST['clearRes']);
// fetching  bed data from the database
	 $r_query = "SELECT b.*,a.available FROM hostel_reserve AS b
	 LEFT JOIN hostels AS a ON a.room_name = b.room_name WHERE b.id = '$bid'";
	 $r_results = mysqli_query($this->_con, $r_query)  or die(mysqli_error());
	 $num_check = mysqli_num_rows($r_results);
	 if($num_check != 0){
	// running the while loop for the table related at the top
	 while($rows = mysqli_fetch_assoc($r_results)){
	   $id = $rows['h_id'];
	   $room_name = $rows['room_name'];
	   $num_room = $rows['num_room'];
	   $available  = $rows['available'];
	   //add back the expire reserves
	   $updateAvailable = $available + $num_room;
	   //delete the booking from the reserve table
	   $d_query = "DELETE FROM reserve_hostel WHERE room_name ='$room_name' LIMIT 1";
	   	 $d_result = mysqli_query($this->_con, $d_query)  or die(mysqli_error());
		 	   //update the booking record
	   $u_query = "UPDATE hostels SET available = '$updateAvailable' WHERE room_name ='$room_name' LIMIT 1";
	   	 $u_result = mysqli_query($this->_con, $u_query)  or die(mysqli_error());
	 }
	 }
}
?>
</div>