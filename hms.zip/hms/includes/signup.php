<?php
require_once("includes/db.con.php");
class Hostel{
	public function __construct()
		{
			$db = new  Database();
			$this->_con = $db->con;
		}
function signupForm(){
if(isset($_POST['signup'])){
$username = mysqli_real_escape_string($this->_con,$_POST['username']);
$email = mysqli_real_escape_string($this->_con,$_POST['email']);
$pass1 = mysqli_real_escape_string($this->_con,$_POST['pass1']);
$pass2 = mysqli_real_escape_string($this->_con,$_POST['pass2']);
$password = md5($pass1);
//checking to if the form was submitted empty
if(empty($username) && empty($email) && empty($pass1) && empty($pass2)){
echo "<span class='error'>All field are required</span>";
}
elseif(empty($username)){
echo "<span class='error'>user name field is required</span>";
}
elseif(empty($email)){
echo"<span class='error'>email field is required</span>";
}
elseif(empty($pass1)){
echo"<span class='error'>password field is required</span>";
}
elseif($pass1 != $pass2){
echo "<span class='error'>password does not match</span>";
}
else{
$insert = "INSERT INTO users(user_name,email,password)VALUES('$username','$email','$password')";
$query = mysqli_query($this->_con,$insert);
if($query){
header("location:thanks.php");
}
else{
echo"<span class='error'>sorry we unable to save your data into our database</span>";
}
return $query;
}
}
}
//login into your profile function
public function login(){
if(isset($_POST['submit'])){
		
//email id		
if(empty($_POST['email'])){
echo'<span class="error">please enter a email.</span> <br />';
}	
else {
$email = mysqli_real_escape_string($this->_con, strip_tags($_POST['email']));
} 		
//password
if(empty($_POST['password'])){
echo'<span class="error">please enter a password.</span>';
}	
else {
$upassword = md5($_POST['password']);
$password = mysqli_real_escape_string($this->_con, $upassword);
}	
		
if (!empty($email)&& !empty($password)){
                    
$sql = "SELECT * FROM users WHERE email='$email' AND password='$password' LIMIT 1";
$result = mysqli_query($this->_con,$sql);
             
if(mysqli_num_rows($result)==1){
$row = mysqli_fetch_array($result);
    $login_email = $row['email'];
    $active = $row['active'];
          $user_id = $row['u_id'];
if(isset($login_email ) && $active == 0){
    $_SESSION['u_id'] = $row['u_id']; 
    $_SESSION['email'] =  $row['email'];
    header('location:home.php?bello=student');
    exit();
    }
elseif(isset($login_email ) && $active == 1){
    $_SESSION['u_id'] = $row['u_id']; 
    $_SESSION['email'] =  $row['email'];
        header('location:home.php');
        exit();
                                            
}   	                                				
}else{
echo'<span class="error"> email ID or password is incorrect</span> <br /> <br />' ;
}
}
}
}
/**
* This will shows account information and handles password change
* @param array $data
* @throws Exception
* @return boolean
*/

public function account( array $data )
{
if( !empty( $data ) ){
// Trim all the incoming data:
$trimmed_data = array_map('trim', $data);

// escape variables for security
$password = mysqli_real_escape_string( $this->_con, $trimmed_data['password'] );
$cpassword = $trimmed_data['confirm_password'];
$user_id = $_SESSION['member_id'];
if((!$password) || (!$cpassword) ) {
throw new Exception( FIELDS_MISSING );
}
if ($password !== $cpassword) {
throw new Exception( PASSWORD_NOT_MATCH );
}
$password = md5( $password );
$query = "UPDATE users SET password = '$password' WHERE id = '$user_id'";
if(mysqli_query($this->_con, $query)){
mysqli_close($this->_con);
return true;
}
} else{
throw new Exception( FIELDS_MISSING );
}
}

/**
* This handle sign out process
*/
public function logout()
{
session_unset();
session_destroy();
session_start();
$_SESSION['success'] = LOGOUT_SUCCESS;
header('Location: index.php');
}
function Reserve_hostel(){
if(isset($_POST['submit'])){
global $user_id;
$reg = mysqli_real_escape_string($this->_con,$_POST['reg']);
$name = mysqli_real_escape_string($this->_con,$_POST['name']);
$gender = mysqli_real_escape_string($this->_con,$_POST['gender']);
$number = mysqli_real_escape_string($this->_con,$_POST['s_number']);
$b_group = mysqli_real_escape_string($this->_con,$_POST['b_group']);
$f_address = mysqli_real_escape_string($this->_con,$_POST['f_address']);
$s_address = mysqli_real_escape_string($this->_con,$_POST['s_address']);
if(empty($reg) ||empty($name) ||empty($gender) ||empty($number) ||empty($b_group) ||empty($f_address) ||empty($s_address)){
echo ' sorry all filed are required';
exit;
}
else if(empty($reg)){
echo 'registration number is required';
exit;
}
else if(empty($name)){
echo 'Name field is required';
exit;
}
else if(empty($number)){
echo 'phone number is required';
exit;
}
else if(empty($b_group)){
echo 'blood group is required';
exit;
}
else if(empty($f_address)){
echo 'first address is required';
exit;
}
else if(empty($s_address)){
echo 'second address is required';
exit;
}
$query = "UPDATE users SET name = '$name', 
				reg_num = '$reg', gender = '$gender',
				phone_num = '$number' , blood_group = '$b_group',
				first_address = '$f_address',
				second_address = '$s_address'WHERE u_id = '$user_id' LIMIT 1";
$result = mysqli_query($this->_con,$query);
if($result){
header("location:home.php?bello=student.next");
}
else{
echo'Sorry fail to insert';
}
return $result;
}
}
}
?>