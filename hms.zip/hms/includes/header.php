<?php 
session_start();
require_once("includes/signup.php");
			if(isset($_SESSION['email']) && $_SESSION['u_id']){
				$_SESSION['u_id'];
			}
			else{
			header('Location: index.php');
			}
?>
<?php
if(isset($_GET['bello'])){
	$pages = array("dashboad","student","hostels","student","student.next","forget_password","all_users");
	if(in_array($_GET['bello'],$pages)){
		$_page = $_GET['bello'];
	}
	else{
	$_page = "all_users";	
	}
}
else{
	$_page = "all_users";
}
?>
<html>
<head>
<title>Hostel Management System</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/hostel.js"></script>
<script type="text/javascript" src="js/pic_upload.js"></script>
<script type="text/javascript" src="js/authenticate.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class=" navbar navbar-default navbar-fixed-top menu" id="my-navbar" >
<div class="navbar-header marg">Hostel Management System</div>
<button type="button" title="Menu Bar" class="navbar-toggle menu" data-toggle="collapse" data-target="#navbar-collapse">
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
</button>
<div class="collapse navbar-collapse" id="navbar-collapse">
<div class="btn-group pull-right" style="margin-top:8px; margin-right:60px;">
<button type="button" class="btn btn-default dropdown-toggle"
data-toggle="dropdown">
Account
<span class="caret"></span>
</button>
<ul class="dropdown-menu" role="menu">
<li><a href="#">my Account</a></li>
<li class="divider"></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
<ul class="nav navbar-nav pull-right">
 <li><a href="home.php?bello=all_users">Home</a></li>
    <li><a href="home.php?bello=hostels">Hostels</a></li>
    <li><a href="home.php?bello=dashboad">Profile</a></li>
</ul>
</div>
</nav>