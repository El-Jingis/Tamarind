<?php
require_once("includes/hostel_query.php");
require_once("includes/conx.php");
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];
}
if(isset($_POST['submit'])){
			// escape variables for security
			$photo = $_FILES["file"]["name"]; // The file name
			$photo_tmp = $_FILES["file"]["tmp_name"]; // File in the PHP tmp folder
			$photo = preg_replace('#[^a-z.0-9]#i', '', $photo); 
			$kaboom = explode(".", $photo); // Split file name into an array using the dot
			$fileExt = end($kaboom); // Now target the last array element to get the file extension
			// START PHP Image Upload Error Handling --------------------------------------------------
			$photo = time().rand().".".$fileExt;
			move_uploaded_file($photo_tmp, "uploads/$photo");
			if(empty($photo)){
			echo 'choose file to upload';
			}
			else{
			$sql = mysqli_query($link,"UPDATE users SET photo = '$photo' WHERE u_id ='$uid'");
			}
			}
?>
<div class="col-lg-3 col-md-3 col-sm-3 bordr" style="margin-left:50px;" >
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 bordr">
<div class="row">
<div class="col-lg-10 col-md-10 col-sm-10 bordr">
<div class="thumbnail bordr">
<?php
	 $query = "SELECT * FROM users  WHERE u_id ='$uid'";
		$results = mysqli_query($link, $query)  or die(mysqli_error());
$all_data = "";
while ( $result = mysqli_fetch_assoc($results)){
$id = $result['u_id'];
$photo = $result['photo'];
}
if($photo != ""){
echo $all_data ="<img src=\"uploads/$photo\" width=\"100%\" height=\"400px\" class=\"bordr\"/>";
}
else{
echo $all_data ="<img src=\"images/user.png\" width=\"100%\" height=\"200\" class=\"bordr\"/>";
}
?>
</div>
</div>
</div>

<div class="form-group" id="pics" style=" display:none;">
<form action="" method='post' enctype='multipart/form-data' id='myForm'>
<div class="form-group">
<input type="hidden" name="me" id="me" class="form-control" />
<input type="file" name="file" id="file" class="form-control" />
</div>
<button class="btn btn-lg btn-md btn-sm btn-default" name="submit">Upload Now</button>
</form>
</div>
<div class="btn-group" style="margin-left:30px;">
<button class="btn btn-lg btn-md btn-sm btn-primary" id="pic">Upload Picture</button>
</div>
</div>
</div><!--row-->
</div><!--col-11 inner-->
</div><!--col-11 inner-->
</div><!--row inner-->
</div><!--col-2-->