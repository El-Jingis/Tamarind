 <?php
//hostel query goes here
require_once("includes/db.con.php");
class Hostel_query{
	public function __construct()
		{
			$db = new  Database();
			$this->_con = $db->con;
		}
//function for fetching data from blocks table of the database.
	function getblock(){
	//fetching data from block table
		$query = "SELECT * FROM hostels";
		$results = mysqli_query($this->_con, $query)  or die(mysqli_error());
		mysqli_close($this->_con);
		return $results;
	 // fetching  bed data from the database
	 $r_query = "SELECT b.*,a.available FROM hostel_reserve AS b
	 LEFT JOIN hostels AS a ON a.room_name = b.room_name WHERE b.id = '$bid'";
	 $r_results = mysqli_query($this->_con, $r_query)  or die(mysqli_error());
	 $num_check = mysqli_num_rows($r_results);
	 if($num_check != 0){
	// running the while loop for the table related at the top
	 while($rows = mysqli_fetch_assoc($r_results)){
	   $id = $rows['h_id'];
	   $room_name = $rows['room_name'];
	   $num_room = $rows['num_room'];
	   $available  = $rows['available'];
	   //add back the expire reserves
	   $updateAvailable = $available + $num_room;
	   //delete the booking from the reserve table
	   $d_query = "DELETE FROM reserve_hostel WHERE room_name ='$room_name' LIMIT 1";
	   	 $d_result = mysqli_query($this->_con, $d_query)  or die(mysqli_error());
		 	   //update the booking record
	   $u_query = "UPDATE hostels SET available = '$updateAvailable' WHERE room_name ='$room_name' LIMIT 1";
	   	 $u_result = mysqli_query($this->_con, $u_query)  or die(mysqli_error());
	 }
	 }
	 }
	 public function get_user(){
	 global $user_id;
	 $query = "SELECT * FROM users WHERE u_id ='$user_id'";
		$results = mysqli_query($this->_con, $query)  or die(mysqli_error());
		mysqli_close($this->_con);
		return $results;
	 }
}
?>