<?php
$host = "localhost";
$username = "root";
$password = "";
$db_name = "hms";
$link = @mysqli_connect($host , $username , $password);
    $select = @mysqli_select_db($link,"hms");


?>