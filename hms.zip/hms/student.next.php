<?php
require_once("includes/conx.php");
//session for the login user
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];

//query for the  student hostel reservation
if(isset($_POST['reserve'])){
//variable
$f_name = mysqli_real_escape_string($link,$_POST['f_name']);
$m_name = mysqli_real_escape_string($link,$_POST['m_name']);
$p_number = mysqli_real_escape_string($link,$_POST['p_number']);
$b_address = mysqli_real_escape_string($link,$_POST['b_address']);
$m_address = mysqli_real_escape_string($link,$_POST['m_address']);
//if the field are empty
if(empty($f_name) ||empty($m_name) ||empty($p_number)||empty($b_address) ||empty($m_address)){
echo ' sorry all filed are required';
exit;
}
else if(empty($f_name)){
echo 'registration number is required';
exit;
}
else if(empty($m_name)){
echo 'Name field is required';
exit;
}
else if(empty($p_number)){
echo 'phone number is required';
exit;
}
else if(empty($b_address)){
echo 'first address is required';
exit;
}
else if(empty($m_address)){
echo 'second address is required';
exit;
}
else{
$query = "UPDATE users SET fathers_name = '$f_name', 
				mothers_name = '$m_name', parant_phone_num = '$p_number' ,
				fathers_address = '$b_address',
				mothers_address = '$m_address' WHERE u_id = '$uid' LIMIT 1";
$result = mysqli_query($link,$query);
if($result){
header("location:home.php?bello=hostels");
}
else{
echo'Sorry fail to insert';
}
}
}
}
?>
<div class="clo-lg-3 clo-md-3 col-sm-3"></div>
<div class="clo-lg-5 clo-md-5 col-sm-5 bord margin">
<div class="bottom"><b>Student Hostel Reservation form</b></div>
<div class="holder">
<div class="form-group">
</div>
<form action="" method="post">
<div class="form-group"><b>Father's Name</b>
<input type="text" name="f_name" class="form-control" placeholder="your Father's name" />
</div><!--form-grouper-->
<div class="form-group"><b>Mother's Name</b>
<input type="text" name="m_name" class="form-control" placeholder="your Mother's name" />
</div><!--form-grouper-->
<div class="form-group"><b> Parent Phone Number</b>
<input type="text" name="p_number" class="form-control" placeholder="your Parent phone number" />
</div><!--form-grouper-->
<div class="form-group"><b>Father's Address</b>
<textarea name="b_address" class="form-control" placeholder="Your Father's Address"></textarea>
</div><!--form-grouper-->
<div class="form-group"><b>Mother's Address</b>
<textarea name="m_address" class="form-control" placeholder="Your Mother's Address"></textarea>
</div><!--form-grouper-->
<div class='form-group'>
<button class="btn btn-block btn-primary" type="submit" name="reserve">Reserve Hostel</button>
</div><!--class cols-->
</form>
</div><!--div holder-->
</div><!--div class col-4-->