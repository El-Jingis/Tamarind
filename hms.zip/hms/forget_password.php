<html>
<head>
<title>Bello project</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.js"></script>
    <script src="js/authenticate.js"></script>
</head>
<body>
<nav class="navbar-inverse header menu" id="my-navbar" >
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-3"></div>
<div class="col-lg-6 col-md-6 col-sm-6">
<div class="navbar-header marg">Hostel Management System</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3"></div>
</div>
</div>
<button type="button" title="Menu Bar" class="navbar-toggle menu" data-toggle="collapse" data-target="#navbar-collapse">
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
</button>
</div><!--navbar header-->
<div class="collapse navbar-collapse" id="navbar-collapse">
</div><!--class collapse-->
</div>
</nav>
<div class="jumbotron bg">
<div class="container">
<div class="row">
<div class="clo-lg-4 clo-md-4 col-sm-4"></div>
<div class="clo-lg-4 clo-md-4 col-sm-4 bord" style="padding:50px;">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" id="forgetpassword-form" method="post"  class="form-register" role="form">
<div class="form-group">
<input id="email" name="email" type="email" class="form-control" placeholder="Email address">  
<span class="help-block"></span>
</div>
<button id="forget_btn" class="btn btn-block btn-primary" type="submit">Reset Password</button>
</form>
<div class="form-footer">
<div class="row">
<div class="col-xs-5 col-sm-5 col-md-5 link">
<i class="fa fa-lock"></i>
<a href="index.php"> Sign In </a>
</div>
<div class="col-lg-5 col-sm-5 col-md-5 link">
<i class="fa fa-check"></i>
<a href="index.php"> Sign Up </a>
</div>
</div>
</div>
</div>
<div class="clo-lg-4 clo-md-4 col-sm-4"></div>
</div>
	<!-- /container -->
  </body>
</html>
   