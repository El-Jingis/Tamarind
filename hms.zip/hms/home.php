<?php
 require_once("includes/header.php");
?>
<div class="jumbotron bg">
<div class="container">
<div class="row">
<?php require($_page.".php");?>

<?php
require_once("includes/sidebar.php");
?>
</div><!--row-->
</div><!--container-->
</div>
</body>