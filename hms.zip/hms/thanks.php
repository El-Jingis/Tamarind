<html>
<head>
<title>Hostel Management System</title>
<link href="css/bello1.css" media="all" rel="stylesheet" />
<link href="css/bello2.css" media="all" rel="stylesheet" />
<link href="css/bello3.css" media="all" rel="stylesheet" />
<link href="css/bello4.css" media="all" rel="stylesheet" />
<link href="css/bello5.css" media="all" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.js"></script>
    <script src="js/authenticate.js"></script>
</head>
<body class="bg">
<nav class=" navbar navbar-default navbar-fixed-top pad menu" id="my-navbar" >
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-3 col-sm-3"></div>
<div class="col-lg-6 col-md-6 col-sm-6">
<div class="navbar-header marg">Hostel Management System</div>
</div>
<div class="col-lg-3 col-md-3 col-sm-3"></div>
</div>
</div>
<button type="button" title="Menu Bar" class="navbar-toggle menu" data-toggle="collapse" data-target="#navbar-collapse">
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
<span class="icon-bar color"></span>
</button>
</div><!--navbar header-->
<div class="collapse navbar-collapse" id="navbar-collapse">
</div><!--class collapse-->
</div>
</nav>
</head>
<body>
<div class="jumbotron bg">
<div class="container">
<div class="clo-lg-2 clo-md-2 col-sm-2"></div><!--class cols-->
<div class="clo-lg-8 clo-md-8 col-sm-8 bord">
<p>thank you for your registration you can  now click here<a href="index.php" class="links btn btn-lg btn-md btn-sm btn-primary">Sign In</a> to continuer with your hostel booking</p>
</div><!--class cols-->
<div class="clo-lg-2 clo-md-2 col-sm-2"></div><!--class cols-->
</div><!--container-->
</div><!--jumbotron-->
</body>
</html>