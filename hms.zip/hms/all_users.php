<div class="clo-lg-8 clo-md-8 col-sm-8 bord">
<?php
//esterblishing  connction to the database
require("includes/conx.php");
$all_data ="";
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];
$sql ="SELECT * FROM users 
INNER JOIN confirm_hostel ON users.reg_num = confirm_hostel.reg_num  WHERE active = '1' LIMIT 10";
$result = mysqli_query($link, $sql);
$num_check = mysqli_num_rows($result);
if($num_check != 0){
while($row = mysqli_fetch_assoc($result)){
 $photo = $row['photo'];
 $name = $row['name'];
 $reg = $row['reg_num'];
 $phone = $row['phone_num'];
  $gender = $row['gender'];
  $hostel = $row['hostel_name'];
 ?>
<?php
echo "<div class=\"container\">
<div class=\"row bords\" style=\"margin:2px;padding:5px;\">
<div class=\"col-lg-5 col-md-5 col-sm-5\" style=\"padding-top:8px;\">

<div class=\"thumbnail pic\">";

 if($photo != ""){
echo "<img src=\"uploads/$photo\" width='100%' height=\"pic\" />";
}
else{
 echo "<img src=\"images/user.png\" width=\"100%\" height=\"200\" />";
}
echo "</div>
</div>
<div class=\"col-lg-7 col-md-7 col-sm-7\"><b>NAME:</b>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$name<br>
<b>REG NUMBER:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $reg<br>
 <b>PHONE NUMBER:</b>&nbsp;&nbsp;&nbsp; $phone<br>
 <b>GENDER:</b>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$gender<br>
 <b>HOSTE NAME:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $hostel
</div>
</div>
</div>";
}
}
else{
echo "<h4>There is no any user that booked a hostel at this moment be the first person to book hostel now.</h4>";
}
}
?>
</div><!--div class col-4-->
