<?php
require_once("includes/hostel_query.php");
//grap data from database table
$blocks = new Hostel_query();
$block = $blocks->getblock();
$all_data = "";
while ( $result = mysqli_fetch_assoc($block)){
$id = $result['h_id'];
$block_name = $result['hostel_name'];
 $block_description = $result['description'];
$room_available = $result['available'];
$block_image = $result['block_image'];
if($block_name == ""){
$all_data .= "0 Room available";
}
else{
?>
<?php
$all_data .= "<div class=\"container\">
<div class=\"row bord\" style=\"margin:8px;\">
<div class=\"col-lg-5 col-md-5 col-sm-5\" style=\"padding-top:8px;\">
<div class=\"thumbnail\"><img src=\"uploads/$block_image\" width='100%'  id=\"tbl_'.$id.'\" onClick=\"showbed(this.id)\" /></div>
<span style=\"color:red; font-weight:bold;\">$room_available</span>Bed(s) available
</div>
<div class=\"col-lg-7 col-md-7 col-sm-7\"><b>$block_name</b><br>
 $block_description
</div>
</div>
</div>";
}
}
?>
<div class="clo-lg-8 clo-md-8 col-sm-8 margins">
<div id="returnData"></div>
<?php
echo $all_data;
    ?>
</div><!--div class col-4-->