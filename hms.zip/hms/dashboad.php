<?php  
require("includes/conx.php");
?>
<?php
if(isset($_SESSION['email']))
{
$uid = $_SESSION['u_id'];
$sql = "select * from users WHERE u_id = '$uid' LIMIT 1";
$result = mysqli_query($link, $sql);
while($row = mysqli_fetch_assoc($result)){
 $email = $row['email'];
 $name = $row['name'];
 $reg = $row['reg_num'];
 $phone = $row['phone_num'];
  $gender = $row['gender'];
 }
 }
 else{
 //header("location:index.php");
 }
?>
<div class="col-lg-8 col-md-8 col-sm-8 bground bord">
<h4><?php echo"<span style='color:#4071a9;'>".$name."</span>DashBoard";?></h4>
<?php
print '<table colspan="18"  style="margin:10px;">';
print '<tr style="margin:10px;"><td></td>';
print'<td style="margin:10px;"><b>EMAIL</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'. $email.'</td></tr>';
print '<tr style="margin:10px;"><td></td>';
print'<td style="margin:10px;"><b>NAME</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'. $name.'</td></tr>';
print '<tr style="margin:10px;"><td></td>';
print '<td style="margin:10px;"><b>REG NUMBER</b></td>&nbsp;&nbsp;&nbsp;&nbsp;<td></td><td>'.$reg.'</td></tr>';
print '<tr style="margin:10px;"><td></td>';
print '<td style="margin:10px;"><b>PHONE NUMBER</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'.$phone.'</td></tr>';
print '<tr style="margin:10px;"><td></td>';
print '<td style="margin:10px;"><b>GENDER</b></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td><td>'.$gender.'</td></tr><br />';
print '</table>';
 ?>
</div><!--col-8-->
